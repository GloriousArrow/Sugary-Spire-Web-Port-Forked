# Sugary Spire Web Port
A Web Port of Sugary Spire

Versions include:
- Playtest 3.2
- P Rank Build (NOT Finalized Build)

Go [HERE](https://github.com/burnedpopcorn/Sugary-Spire-Web-Port/tree/SS-Playtest-3.2) for Playtest, and Go [HERE](https://github.com/burnedpopcorn/Sugary-Spire-Web-Port/tree/SS_P-Rank) for P rank
